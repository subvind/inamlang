inomscript
========
a text parser... 
- that converts code or inomscript 8)
- to runnable rustlang &)
- for flow-based devgramming :)

part of ecosystem...
- [fbd :: sync :: subvind/inomscript](https://github.com/subvind/inomscript)
- [www :: top :: subvind/ucimecu](https://github.com/subvind/ucimecu)
- [server :: backend :: subvind/isisis](https://github.com/subvind/isisis)
- [client :: frontend :: subvind/autoide](https://github.com/subvind/autoide)
